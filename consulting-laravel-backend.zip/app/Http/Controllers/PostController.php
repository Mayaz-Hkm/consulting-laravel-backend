<?php
namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    /**
     * Display the specified post with comments and replies.
     */
    public function show($id)
    {
        $post = Post::with(['user', 'comments.replies' => function($query) {
            $query->orderBy('created_at', 'asc'); // ترتيب الردود حسب تاريخ الإنشاء
        }])->findOrFail($id);

        return response()->json($post);
    }

    /**
     * Store a newly created comment (main comment or reply).
     */
    public function storeComment(Request $request)
    {
        $request->validate([
            'post_id' => 'required|exists:posts,id',
            'content' => 'required|string',
            'parent_id' => 'nullable|exists:comments,id' // يسمح بإضافة رد على تعليق آخر
        ]);

        $comment = new Comment();
        $comment->post_id = $request->post_id;
        $comment->user_id = Auth::id();
        $comment->content = $request->content;
        $comment->parent_id = $request->parent_id; // إذا كان الرد على تعليق آخر
        $comment->save();

        return response()->json(['message' => 'Comment added successfully', 'comment' => $comment]);
    }

    /**
     * Update the specified comment. Only the owner can update it.
     */
    public function updateComment(Request $request, $commentId)
    {
        $comment = Comment::findOrFail($commentId);

        if ($comment->user_id !== Auth::id()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $comment->update($request->only(['content']));
        return response()->json(['message' => 'Comment updated successfully', 'comment' => $comment]);
    }

    /**
     * Remove the specified comment from storage. This will also delete its replies.
     */
    public function destroyComment($commentId)
    {
        $comment = Comment::findOrFail($commentId);

        if ($comment->user_id !== Auth::id()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        // Delete all replies associated with this comment
        $comment->replies()->delete();

        // Delete the comment itself
        $comment->delete();

        return response()->json(['message' => 'Comment and its replies deleted successfully']);
    }
}
