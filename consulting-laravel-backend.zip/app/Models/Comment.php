<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    use HasFactory;

    protected $fillable = [
        'post_id', 'user_id', 'content', 'parent_id'
    ];

    // علاقة مع المنشور (Post)
    public function post()
    {
        return $this->belongsTo(Post::class);
    }

    // علاقة مع المستخدم (User)
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // علاقة مع التعليقات الردود (Replies)
    public function replies()
    {
        return $this->hasMany(Comment::class, 'parent_id');
    }

    // علاقة مع التعليق الرئيسي (Parent Comment)
    public function parent()
    {
        return $this->belongsTo(Comment::class, 'parent_id');
    }
}
